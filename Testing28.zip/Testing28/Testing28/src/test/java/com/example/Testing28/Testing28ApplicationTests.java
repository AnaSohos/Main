package com.example.Testing28;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Testing28ApplicationTests {

	@Test
	void contextLoads() {
	}

}
